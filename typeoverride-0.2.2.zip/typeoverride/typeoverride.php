<?php
/**
 * Plugin Name: TypeOverride
 * Description: Find and reset local typography overrides in Elementor.
 * Version: 0.2.2
 * Requires at least: 6.8
 * Requires PHP: 7.4
 * Author: Savage Creative
 * Author URI: https://mynameissavage.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: typeoverride
 * Requires Plugins: elementor
 *
 * @package TypeOverride
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'TYPEOVERRIDE_VERSION' ) ) {
	define( 'TYPEOVERRIDE_VERSION', '0.2.2' );
}

class TypeOverride_Typography_Manager {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-typeoverride-elementor-helper.php';
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-typeoverride-matcher.php';
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-typeoverride-scanner.php';
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-typeoverride-resetter.php';
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-typeoverride-admin.php';

		add_action( 'plugins_loaded', array( $this, 'boot' ) );
	}

	public function boot() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'elementor_inactive_notice' ) );
		}

		new TypeOverride_Admin();
	}

	public function elementor_inactive_notice() {
		if ( did_action( 'elementor/loaded' ) ) {
			return;
		}

		?>
		<div class="notice notice-error">
			<p><strong><?php echo esc_html__( 'TypeOverride', 'typeoverride' ); ?></strong> <?php echo esc_html__( 'requires Elementor to be installed and active to function.', 'typeoverride' ); ?></p>
		</div>
		<?php
	}
}

TypeOverride_Typography_Manager::get_instance();
