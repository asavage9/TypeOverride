<?php
/**
 * WordPress admin interface.
 *
 * @package TypeOverride
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TypeOverride_Admin {

	private $page_slug = 'typeoverride';

	private $version = '0.2.2';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
		add_action( 'admin_init', array( $this, 'handle_actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function add_menu_page() {
		add_menu_page(
			__( 'TypeOverride', 'typeoverride' ),
			__( 'TypeOverride', 'typeoverride' ),
			'manage_options',
			$this->page_slug,
			array( $this, 'render_page' ),
			$this->get_menu_icon(),
			80
		);
	}

	private function get_menu_icon() {
		$icon_path = dirname( __DIR__ ) . '/admin/images/typeoverride-admin-menu.svg';

		if ( ! is_readable( $icon_path ) ) {
			return 'dashicons-editor-textcolor';
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Read the packaged local SVG asset without introducing a runtime dependency.
		$icon = file_get_contents( $icon_path );
		if ( false === $icon || '' === trim( $icon ) ) {
			return 'dashicons-editor-textcolor';
		}

		return 'data:image/svg+xml;base64,' . base64_encode( $icon );
	}

	public function enqueue_assets() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This GET parameter only selects the TypeOverride admin screen.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( $this->page_slug !== $page ) {
			return;
		}

		$plugin_file = dirname( __DIR__ ) . '/typeoverride.php';
		wp_enqueue_style(
			'typeoverride-admin',
			plugins_url( 'admin/css/typeoverride-admin.css', $plugin_file ),
			array(),
			$this->version
		);
		wp_enqueue_script(
			'typeoverride-admin',
			plugins_url( 'admin/js/typeoverride-admin.js', $plugin_file ),
			array( 'wp-i18n' ),
			$this->version,
			true
		);
		wp_set_script_translations( 'typeoverride-admin', 'typeoverride', dirname( __DIR__ ) . '/languages' );
	}

	public function handle_actions() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( $this->page_slug !== $page ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'typeoverride' ) );
		}

		$request_method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '';
		$action         = isset( $_POST['typeoverride_action'] ) ? sanitize_key( wp_unslash( $_POST['typeoverride_action'] ) ) : '';
		if ( 'post' === $request_method && 'reset_overrides' === $action ) {
			check_admin_referer( 'typeoverride_reset_action', 'typeoverride_nonce' );
			$this->process_reset();
		}
	}

	private function process_reset() {
		if ( ! $this->is_elementor_available() ) {
			$results = array(
				'modified_docs' => 0,
				'reset_count'   => 0,
				'errors'        => array( __( 'Elementor is unavailable. No reset was performed.', 'typeoverride' ) ),
			);
			set_transient( 'typeoverride_reset_result', $results, MINUTE_IN_SECONDS );
			wp_safe_redirect( $this->page_url( 'reset', array( 'reset' => 'completed' ) ) );
			exit;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The reset nonce is verified in handle_actions before this method runs; scalar values are filtered and sanitized immediately below.
		$submitted_groups = isset( $_POST['reset_groups'] ) ? wp_unslash( $_POST['reset_groups'] ) : array();
		$submitted_groups = array_filter(
			(array) $submitted_groups,
			'is_string'
		);
		$submitted_groups = array_map( 'sanitize_key', $submitted_groups );
		$selected_groups = array_values(
			array_intersect(
				$submitted_groups,
				array_keys( TypeOverride_Matcher::get_groups() )
			)
		);

		if ( empty( $selected_groups ) ) {
			$results = array(
				'modified_docs' => 0,
				'reset_count'   => 0,
				'errors'        => array( __( 'No valid typography groups were selected.', 'typeoverride' ) ),
			);
			set_transient( 'typeoverride_reset_result', $results, MINUTE_IN_SECONDS );
			wp_safe_redirect( $this->page_url( 'reset', array( 'reset' => 'completed' ) ) );
			exit;
		}

		$results = array(
			'modified_docs' => 0,
			'reset_count'   => 0,
			'errors'        => array(),
		);

		$query = new WP_Query(
			array(
				'post_type'      => 'any',
				'post_status'    => array( 'publish', 'pending', 'draft', 'future', 'private' ),
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'meta_query'     => array(
					array(
						'key'     => '_elementor_data',
						'compare' => 'EXISTS',
					),
				),
			)
		);

		foreach ( $query->posts as $post ) {
			if ( TypeOverride_Elementor_Helper::is_active_kit( $post->ID ) ) {
				continue;
			}

			$result = TypeOverride_Resetter::reset_document( $post->ID, $selected_groups );
			if ( ! is_array( $result ) || empty( $result['success'] ) ) {
				$error = is_array( $result ) && ! empty( $result['error'] )
					? $result['error']
					: __( 'The reset failed safely. No changes were recorded.', 'typeoverride' );
				$results['errors'][] = sprintf(
					/* translators: 1: document ID, 2: error message. */
					__( 'Doc ID %1$d: %2$s', 'typeoverride' ),
					(int) $post->ID,
					$error
				);
				continue;
			}

			if ( ! empty( $result['reset_count'] ) ) {
				$results['modified_docs']++;
				$results['reset_count'] += $result['reset_count'];
			}
		}

		if ( $results['reset_count'] > 0 ) {
			TypeOverride_Elementor_Helper::regenerate_css();
		}

		set_transient( 'typeoverride_reset_result', $results, MINUTE_IN_SECONDS );
		wp_safe_redirect( $this->page_url( 'reset', array( 'reset' => 'completed' ) ) );
		exit;
	}

	public function render_page() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This GET parameter only selects the TypeOverride tab.
		$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'audit';
		if ( ! in_array( $current_tab, array( 'audit', 'reset' ), true ) ) {
			$current_tab = 'audit';
		}

		$elementor_available = $this->is_elementor_available();
		?>
		<div class="wrap typeoverride-admin-page">
			<?php $this->render_header( $elementor_available ); ?>
			<?php $this->render_reset_notice(); ?>

			<?php if ( ! $elementor_available ) : ?>
				<?php $this->render_dependency_state(); ?>
			</div>
				<?php
				return;
			endif;
			?>

			<nav class="typeoverride-tabs" aria-label="<?php echo esc_attr__( 'TypeOverride sections', 'typeoverride' ); ?>">
				<a href="<?php echo esc_url( $this->page_url( 'audit' ) ); ?>" class="typeoverride-tab <?php echo 'audit' === $current_tab ? 'is-active' : ''; ?>" <?php echo 'audit' === $current_tab ? 'aria-current="page"' : ''; ?>><?php echo esc_html__( 'Audit', 'typeoverride' ); ?></a>
				<a href="<?php echo esc_url( $this->page_url( 'reset' ) ); ?>" class="typeoverride-tab <?php echo 'reset' === $current_tab ? 'is-active' : ''; ?>" <?php echo 'reset' === $current_tab ? 'aria-current="page"' : ''; ?>><?php echo esc_html__( 'Reset Overrides', 'typeoverride' ); ?></a>
			</nav>

			<main class="typeoverride-content">
				<?php
				if ( 'audit' === $current_tab ) {
					$this->render_audit_tab();
				} else {
					$this->render_reset_tab();
				}
				?>
			</main>
		</div>
		<?php
	}

	private function render_header( $elementor_available ) {
		$plugin_file = dirname( __DIR__ ) . '/typeoverride.php';
		$lockup_url  = plugins_url( 'admin/images/typeoverride-lockup-horizontal.svg', $plugin_file );
		$status_label = $elementor_available ? __( 'Elementor detected', 'typeoverride' ) : __( 'Elementor unavailable', 'typeoverride' );
		$status_class = $elementor_available ? 'is-ready' : 'is-unavailable';
		$version_label = sprintf(
			/* translators: %s: plugin version. */
			__( 'v%s', 'typeoverride' ),
			$this->version
		);
		?>
		<header class="typeoverride-header">
			<div class="typeoverride-header-copy">
				<p class="typeoverride-eyebrow"><?php echo esc_html__( 'Elementor typography utility', 'typeoverride' ); ?></p>
				<div class="typeoverride-header-lockup">
					<img src="<?php echo esc_url( $lockup_url ); ?>" alt="" aria-hidden="true">
					<h1 class="screen-reader-text"><?php echo esc_html__( 'TypeOverride', 'typeoverride' ); ?></h1>
				</div>
				<p class="typeoverride-subtitle"><?php echo esc_html__( 'Find and reset local typography overrides in Elementor.', 'typeoverride' ); ?></p>
			</div>
			<div class="typeoverride-header-meta" aria-label="<?php echo esc_attr__( 'TypeOverride status', 'typeoverride' ); ?>">
				<span class="typeoverride-status <?php echo esc_attr( $status_class ); ?>">
					<span class="typeoverride-status-dot" aria-hidden="true"></span>
					<?php echo esc_html( $status_label ); ?>
				</span>
				<span class="typeoverride-version"><?php echo esc_html( $version_label ); ?></span>
			</div>
		</header>
		<?php
	}

	private function render_reset_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This GET parameter only selects a transient result view.
		if ( ! isset( $_GET['reset'] ) || 'completed' !== sanitize_key( wp_unslash( $_GET['reset'] ) ) ) {
			return;
		}

		$result = get_transient( 'typeoverride_reset_result' );
		if ( ! is_array( $result ) ) {
			return;
		}

		$has_errors  = ! empty( $result['errors'] );
		$has_changes = (int) $result['reset_count'] > 0;
		if ( ! $has_errors ) {
			$state   = 'success';
			$heading = __( 'Typography overrides reset successfully', 'typeoverride' );
		} elseif ( $has_changes ) {
			$state   = 'warning';
			$heading = __( 'Reset completed with skipped items', 'typeoverride' );
		} else {
			$state   = 'error';
			$heading = __( 'Reset could not complete', 'typeoverride' );
		}
		?>
		<section class="typeoverride-result typeoverride-result-<?php echo esc_attr( $state ); ?>" role="<?php echo 'error' === $state ? 'alert' : 'status'; ?>">
			<div class="typeoverride-result-icon" aria-hidden="true"><?php echo 'success' === $state ? '✓' : ( 'warning' === $state ? '!' : '×' ); ?></div>
			<div class="typeoverride-result-body">
				<h2><?php echo esc_html( $heading ); ?></h2>
				<?php if ( $has_errors && $has_changes ) : ?>
					<p><?php echo esc_html__( 'Completed changes are listed below. Review the skipped or failed items before trying again.', 'typeoverride' ); ?></p>
				<?php elseif ( $has_errors ) : ?>
					<p><?php echo esc_html__( 'No documents were modified. Review the reported items before trying again.', 'typeoverride' ); ?></p>
				<?php else : ?>
					<p><?php echo esc_html__( 'Selected local values were cleared so Elementor can use its available default or global inheritance.', 'typeoverride' ); ?></p>
				<?php endif; ?>
				<div class="typeoverride-result-metrics" aria-label="<?php echo esc_attr__( 'Reset results', 'typeoverride' ); ?>">
					<div><span><?php echo esc_html__( 'Documents modified', 'typeoverride' ); ?></span><strong><?php echo (int) $result['modified_docs']; ?></strong></div>
					<div><span><?php echo esc_html__( 'Overrides reset', 'typeoverride' ); ?></span><strong><?php echo (int) $result['reset_count']; ?></strong></div>
				</div>
				<?php if ( $has_errors ) : ?>
					<h3><?php echo esc_html__( 'Skipped or failed items', 'typeoverride' ); ?></h3>
					<ul>
						<?php foreach ( $result['errors'] as $error ) : ?>
							<li><?php echo esc_html( $error ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<p class="typeoverride-result-footnote"><?php echo esc_html__( 'If cached styles remain, regenerate Elementor files/data from Elementor Tools.', 'typeoverride' ); ?></p>
			</div>
		</section>
		<?php
		delete_transient( 'typeoverride_reset_result' );
	}

	private function render_dependency_state() {
		?>
		<section class="typeoverride-panel typeoverride-state typeoverride-state-unavailable" role="status" aria-labelledby="typeoverride-dependency-title">
			<div class="typeoverride-state-icon" aria-hidden="true">!</div>
			<div>
				<p class="typeoverride-eyebrow"><?php echo esc_html__( 'Dependency check', 'typeoverride' ); ?></p>
				<h2 id="typeoverride-dependency-title"><?php echo esc_html__( 'Elementor is unavailable', 'typeoverride' ); ?></h2>
				<p><?php echo esc_html__( 'TypeOverride requires Elementor to inspect typography overrides. Activate Elementor, then return here to run an audit or reset.', 'typeoverride' ); ?></p>
			</div>
		</section>
		<?php
	}

	private function render_audit_tab() {
		$audit = $this->collect_audit_results();
		$skipped_message = sprintf(
			/* translators: %d: number of skipped documents. */
			_n( '%d document could not be inspected safely, so it was left unchanged.', '%d documents could not be inspected safely, so they were left unchanged.', (int) $audit['skipped_count'], 'typeoverride' ),
			(int) $audit['skipped_count']
		);
		$affected_documents_label = sprintf(
			/* translators: %d: number of affected documents. */
			_n( '%d document', '%d documents', (int) $audit['docs_affected'], 'typeoverride' ),
			(int) $audit['docs_affected']
		);
		?>
		<section class="typeoverride-intro" aria-labelledby="typeoverride-audit-title">
			<p class="typeoverride-eyebrow"><?php echo esc_html__( 'Audit', 'typeoverride' ); ?></p>
			<h2 id="typeoverride-audit-title"><?php echo esc_html__( 'What is overriding my global typography?', 'typeoverride' ); ?></h2>
			<p><?php echo esc_html__( 'Review explicit local typography values across Elementor documents before deciding what to reset.', 'typeoverride' ); ?></p>
		</section>

		<?php if ( $audit['skipped_count'] > 0 ) : ?>
			<section class="typeoverride-state typeoverride-state-warning" role="status" aria-labelledby="typeoverride-audit-warning-title">
				<div class="typeoverride-state-icon" aria-hidden="true">!</div>
				<div>
					<h2 id="typeoverride-audit-warning-title"><?php echo esc_html__( 'Audit completed with skipped items', 'typeoverride' ); ?></h2>
					<p><?php echo esc_html( $skipped_message ); ?></p>
					<ul>
						<?php foreach ( $audit['skipped_docs'] as $skipped ) : ?>
							<li><?php echo esc_html( $skipped['title'] ); ?> (ID <?php echo (int) $skipped['id']; ?>): <?php echo esc_html( $skipped['reason'] ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</section>
		<?php endif; ?>

		<?php if ( empty( $audit['documents'] ) ) : ?>
			<section class="typeoverride-panel typeoverride-empty-state" role="status">
				<div class="typeoverride-empty-icon" aria-hidden="true">✓</div>
				<h2><?php echo esc_html__( 'No local typography overrides found', 'typeoverride' ); ?></h2>
				<p><?php echo esc_html( $audit['skipped_count'] > 0 ? __( 'No overrides were found in the documents that completed the audit.', 'typeoverride' ) : __( 'Elementor typography in the audited content is already inheriting its available global/default settings.', 'typeoverride' ) ); ?></p>
			</section>
			<?php
			return;
		endif;
		?>

		<section class="typeoverride-summary" aria-label="<?php echo esc_attr__( 'Audit summary', 'typeoverride' ); ?>">
			<div class="typeoverride-summary-grid <?php echo $audit['skipped_count'] > 0 ? 'has-attention' : 'two-columns'; ?>">
				<div class="typeoverride-stat">
					<span class="typeoverride-stat-label"><?php echo esc_html__( 'Affected Documents', 'typeoverride' ); ?></span>
					<strong class="typeoverride-stat-value"><?php echo (int) $audit['docs_affected']; ?></strong>
					<span class="typeoverride-stat-note"><?php echo esc_html__( 'Documents with local values', 'typeoverride' ); ?></span>
				</div>
				<div class="typeoverride-stat">
					<span class="typeoverride-stat-label"><?php echo esc_html__( 'Local Overrides', 'typeoverride' ); ?></span>
					<strong class="typeoverride-stat-value"><?php echo (int) $audit['override_count']; ?></strong>
					<span class="typeoverride-stat-note"><?php echo esc_html__( 'Explicit values found', 'typeoverride' ); ?></span>
				</div>
				<?php if ( $audit['skipped_count'] > 0 ) : ?>
					<div class="typeoverride-stat typeoverride-stat-attention">
						<span class="typeoverride-stat-label"><?php echo esc_html__( 'Needs Attention', 'typeoverride' ); ?></span>
						<strong class="typeoverride-stat-value"><?php echo (int) $audit['skipped_count']; ?></strong>
						<span class="typeoverride-stat-note"><?php echo esc_html__( 'Documents skipped safely', 'typeoverride' ); ?></span>
					</div>
				<?php endif; ?>
			</div>
			<div class="typeoverride-category-summary" aria-label="<?php echo esc_attr__( 'Overrides by typography category', 'typeoverride' ); ?>">
				<?php foreach ( $audit['group_counts'] as $group => $count ) : ?>
					<span class="typeoverride-count-chip"><span><?php echo esc_html( $this->group_label( $group ) ); ?></span><strong><?php echo (int) $count; ?></strong></span>
				<?php endforeach; ?>
			</div>
		</section>

		<section class="typeoverride-results" aria-labelledby="typeoverride-results-title">
			<div class="typeoverride-section-heading">
				<div>
					<p class="typeoverride-eyebrow"><?php echo esc_html__( 'Findings', 'typeoverride' ); ?></p>
					<h2 id="typeoverride-results-title"><?php echo esc_html__( 'Affected documents', 'typeoverride' ); ?></h2>
				</div>
				<span class="typeoverride-section-count"><?php echo esc_html( $affected_documents_label ); ?></span>
			</div>
			<div class="typeoverride-document-list">
				<?php foreach ( $audit['documents'] as $document ) : ?>
					<?php
					$document_count_label = sprintf(
						/* translators: %d: number of overrides in the document. */
						_n( '%d override', '%d overrides', (int) $document['count'], 'typeoverride' ),
						(int) $document['count']
					);
					$document_caption = sprintf(
						/* translators: %s: document title. */
						__( 'Typography overrides for %s', 'typeoverride' ),
						$document['title']
					);
					?>
					<details class="typeoverride-document">
						<summary>
							<span class="typeoverride-document-heading">
								<strong><?php echo esc_html( $document['title'] ); ?></strong>
								<span><?php echo esc_html( $document['post_type'] ); ?> · ID <?php echo (int) $document['id']; ?></span>
							</span>
							<span class="typeoverride-document-count"><?php echo esc_html( $document_count_label ); ?></span>
						</summary>
						<div class="typeoverride-document-body">
							<table class="typeoverride-override-table">
								<caption class="screen-reader-text"><?php echo esc_html( $document_caption ); ?></caption>
								<thead>
									<tr><th scope="col"><?php echo esc_html__( 'Property', 'typeoverride' ); ?></th><th scope="col"><?php echo esc_html__( 'Context', 'typeoverride' ); ?></th><th scope="col"><?php echo esc_html__( 'Current Value', 'typeoverride' ); ?></th></tr>
								</thead>
								<tbody>
									<?php foreach ( $document['overrides'] as $override ) : ?>
										<tr>
											<td data-label="<?php echo esc_attr__( 'Property', 'typeoverride' ); ?>"><strong><?php echo esc_html( $this->group_label( $override['group'] ) ); ?></strong></td>
											<td data-label="<?php echo esc_attr__( 'Context', 'typeoverride' ); ?>"><?php echo esc_html( $override['context'] ); ?></td>
											<td data-label="<?php echo esc_attr__( 'Current Value', 'typeoverride' ); ?>"><code class="typeoverride-value" title="<?php echo esc_attr( $override['key'] ); ?>"><?php echo esc_html( $this->format_value( $override['value'] ) ); ?></code></td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</details>
				<?php endforeach; ?>
			</div>
		</section>
		<?php
	}

	private function collect_audit_results() {
		$results = array(
			'documents'      => array(),
			'docs_affected'  => 0,
			'override_count' => 0,
			'group_counts'   => array_fill_keys( array_keys( TypeOverride_Matcher::get_groups() ), 0 ),
			'skipped_count'  => 0,
			'skipped_docs'   => array(),
		);

		$query = new WP_Query(
			array(
				'post_type'      => 'any',
				'post_status'    => array( 'publish', 'pending', 'draft', 'future', 'private' ),
				'posts_per_page' => -1,
				'no_found_rows'  => true,
				'meta_query'     => array(
					array(
						'key'     => '_elementor_data',
						'compare' => 'EXISTS',
					),
				),
			)
		);

		foreach ( $query->posts as $post ) {
			if ( TypeOverride_Elementor_Helper::is_active_kit( $post->ID ) ) {
				continue;
			}

			$raw_data = get_post_meta( $post->ID, '_elementor_data', true );
			$data     = is_string( $raw_data ) ? json_decode( $raw_data, true ) : null;
			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
				$results['skipped_count']++;
				$results['skipped_docs'][] = array(
					'id'     => $post->ID,
					'title'  => get_the_title( $post->ID ),
					'reason' => 'Malformed or unavailable Elementor data.',
				);
				continue;
			}

			$overrides = TypeOverride_Scanner::audit_document( $data );
			if ( empty( $overrides ) ) {
				continue;
			}

			$document_overrides = array();
			foreach ( $overrides as $override ) {
				$breakpoint = TypeOverride_Matcher::get_breakpoint_from_key( $override['key'] );
				$document_overrides[] = array(
					'group'   => $override['group'],
					'key'     => $override['key'],
					'value'   => $override['value'],
					'context' => false === $breakpoint ? 'Desktop' : $this->format_breakpoint_label( $breakpoint ),
				);
				$results['group_counts'][ $override['group'] ]++;
			}

			$results['documents'][] = array(
				'id'        => $post->ID,
				'title'     => get_the_title( $post->ID ),
				'post_type' => $this->post_type_label( $post ),
				'count'     => count( $document_overrides ),
				'overrides' => $document_overrides,
			);
			$results['docs_affected']++;
			$results['override_count'] += count( $document_overrides );
		}

		return $results;
	}

	private function render_reset_tab() {
		?>
		<section class="typeoverride-intro" aria-labelledby="typeoverride-reset-title">
			<p class="typeoverride-eyebrow"><?php echo esc_html__( 'Reset Overrides', 'typeoverride' ); ?></p>
			<h2 id="typeoverride-reset-title"><?php echo esc_html__( 'Reset local typography overrides', 'typeoverride' ); ?></h2>
			<p><?php echo esc_html__( "Remove selected explicit local Elementor values so those properties can return to Elementor's Default or inherited behavior.", 'typeoverride' ); ?></p>
		</section>

		<?php $this->render_protection_panel(); ?>

		<form class="typeoverride-reset-form" method="post" action="<?php echo esc_url( $this->page_url( 'reset' ) ); ?>" data-typeoverride-reset-form>
			<?php wp_nonce_field( 'typeoverride_reset_action', 'typeoverride_nonce' ); ?>
			<input type="hidden" name="typeoverride_action" value="reset_overrides">

			<fieldset class="typeoverride-category-fieldset">
				<legend class="typeoverride-section-title"><?php echo esc_html__( 'Choose typography properties', 'typeoverride' ); ?></legend>
				<p class="typeoverride-section-description"><?php echo esc_html__( 'Only the properties you select will be cleared. Responsive variants are included when they match the same property.', 'typeoverride' ); ?></p>
				<div class="typeoverride-category-grid">
					<?php foreach ( TypeOverride_Matcher::get_groups() as $group_id => $identifier ) : ?>
						<?php $label = $this->group_label( $group_id ); ?>
						<label class="typeoverride-category-card" for="typeoverride-group-<?php echo esc_attr( $group_id ); ?>">
							<input class="typeoverride-category-checkbox" type="checkbox" id="typeoverride-group-<?php echo esc_attr( $group_id ); ?>" name="reset_groups[]" value="<?php echo esc_attr( $group_id ); ?>" data-group-label="<?php echo esc_attr( $label ); ?>">
							<span class="typeoverride-category-copy">
								<strong><?php echo esc_html( $label ); ?></strong>
								<span><?php echo esc_html__( 'Remove explicit local values', 'typeoverride' ); ?></span>
							</span>
						</label>
					<?php endforeach; ?>
				</div>
			</fieldset>

			<div class="typeoverride-selection-toolbar">
				<div class="typeoverride-selection-tools" aria-label="<?php echo esc_attr__( 'Selection tools', 'typeoverride' ); ?>">
					<button type="button" class="typeoverride-button typeoverride-button-secondary" data-typeoverride-select-all><?php echo esc_html__( 'Select all', 'typeoverride' ); ?></button>
					<button type="button" class="typeoverride-button typeoverride-button-secondary" data-typeoverride-clear-selection><?php echo esc_html__( 'Clear selection', 'typeoverride' ); ?></button>
				</div>
				<div class="typeoverride-selection-status" role="status" aria-live="polite">
					<strong data-typeoverride-selection-count>0 <?php echo esc_html__( 'selected', 'typeoverride' ); ?></strong>
					<span data-typeoverride-selection-help><?php echo esc_html__( 'Select one or more typography properties to continue.', 'typeoverride' ); ?></span>
				</div>
			</div>

			<div class="typeoverride-form-actions">
				<button type="submit" class="typeoverride-button typeoverride-button-primary" data-typeoverride-review aria-controls="typeoverride-review-panel" disabled><?php echo esc_html__( 'Review reset', 'typeoverride' ); ?></button>
			</div>

			<section id="typeoverride-review-panel" class="typeoverride-review-panel" data-typeoverride-review-panel hidden aria-labelledby="typeoverride-review-title">
				<div>
					<p class="typeoverride-eyebrow"><?php echo esc_html__( 'Final review', 'typeoverride' ); ?></p>
					<h2 id="typeoverride-review-title"><?php echo esc_html__( 'You are about to reset:', 'typeoverride' ); ?></h2>
					<ul class="typeoverride-review-list" data-typeoverride-review-list></ul>
				</div>
				<p class="typeoverride-review-copy"><?php echo esc_html__( 'The selected explicit local values will be cleared across eligible Elementor documents. Global Typography, the active Kit, and unselected properties remain protected.', 'typeoverride' ); ?></p>
				<div class="typeoverride-form-actions typeoverride-review-actions">
					<button type="submit" class="typeoverride-button typeoverride-button-danger" data-typeoverride-confirm hidden><?php echo esc_html__( 'Reset selected overrides', 'typeoverride' ); ?></button>
					<button type="button" class="typeoverride-button typeoverride-button-secondary" data-typeoverride-cancel><?php echo esc_html__( 'Cancel', 'typeoverride' ); ?></button>
				</div>
			</section>
		</form>
		<?php
	}

	private function render_protection_panel() {
		?>
		<section class="typeoverride-panel typeoverride-protection-panel" aria-labelledby="typeoverride-protection-title">
			<div>
				<p class="typeoverride-eyebrow"><?php echo esc_html__( 'Safety boundary', 'typeoverride' ); ?></p>
				<h2 id="typeoverride-protection-title"><?php echo esc_html__( 'What remains protected', 'typeoverride' ); ?></h2>
			</div>
			<ul class="typeoverride-protection-list">
				<li><span aria-hidden="true">✓</span> <?php echo esc_html__( 'Global Typography is not deleted', 'typeoverride' ); ?></li>
				<li><span aria-hidden="true">✓</span> <?php echo esc_html__( "Elementor's active Kit is protected", 'typeoverride' ); ?></li>
				<li><span aria-hidden="true">✓</span> <?php echo esc_html__( 'Unselected typography properties remain unchanged', 'typeoverride' ); ?></li>
				<li><span aria-hidden="true">✓</span> <?php echo esc_html__( 'Original Elementor document data is backed up before modification', 'typeoverride' ); ?></li>
			</ul>
		</section>
		<?php
	}

	private function group_label( $group_id ) {
		$labels = array(
			'font_family'     => __( 'Font Family', 'typeoverride' ),
			'font_size'       => __( 'Font Size', 'typeoverride' ),
			'font_weight'     => __( 'Font Weight', 'typeoverride' ),
			'text_transform'  => __( 'Text Transform', 'typeoverride' ),
			'font_style'      => __( 'Font Style', 'typeoverride' ),
			'text_decoration' => __( 'Text Decoration', 'typeoverride' ),
			'line_height'     => __( 'Line Height', 'typeoverride' ),
			'letter_spacing'  => __( 'Letter Spacing', 'typeoverride' ),
			'word_spacing'    => __( 'Word Spacing', 'typeoverride' ),
		);

		return isset( $labels[ $group_id ] ) ? $labels[ $group_id ] : ucwords( str_replace( '_', ' ', $group_id ) );
	}

	private function format_breakpoint_label( $breakpoint ) {
		$labels = array(
			'tablet'       => __( 'Tablet', 'typeoverride' ),
			'mobile'       => __( 'Mobile', 'typeoverride' ),
			'widescreen'   => __( 'Widescreen', 'typeoverride' ),
			'laptop'       => __( 'Laptop', 'typeoverride' ),
			'tablet_extra' => __( 'Tablet Extra', 'typeoverride' ),
			'mobile_extra' => __( 'Mobile Extra', 'typeoverride' ),
		);
		$breakpoint = (string) $breakpoint;

		return isset( $labels[ $breakpoint ] ) ? $labels[ $breakpoint ] : ucwords( str_replace( '_', ' ', $breakpoint ) );
	}

	private function post_type_label( $post ) {
		$post_type_object = get_post_type_object( $post->post_type );
		if ( $post_type_object && isset( $post_type_object->labels->singular_name ) ) {
			return $post_type_object->labels->singular_name;
		}

		return ucwords( str_replace( '_', ' ', $post->post_type ) );
	}

	private function format_value( $value ) {
		if ( is_array( $value ) ) {
			if ( array_key_exists( 'size', $value ) ) {
				$formatted = (string) $value['size'];
				if ( isset( $value['unit'] ) && '' !== (string) $value['unit'] ) {
					$formatted .= (string) $value['unit'];
				}

				return $formatted;
			}

			$encoded = wp_json_encode( $value );
			return false === $encoded ? __( 'Unable to display value.', 'typeoverride' ) : $encoded;
		}

		if ( is_bool( $value ) ) {
			return $value ? 'true' : 'false';
		}

		return null === $value ? '' : (string) $value;
	}

	private function is_elementor_available() {
		return did_action( 'elementor/loaded' ) > 0 && class_exists( '\Elementor\Plugin' );
	}

	private function page_url( $tab, $extra = array() ) {
		$args = array_merge(
			array(
				'page' => $this->page_slug,
				'tab'  => $tab,
			),
			$extra
		);

		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}
}
